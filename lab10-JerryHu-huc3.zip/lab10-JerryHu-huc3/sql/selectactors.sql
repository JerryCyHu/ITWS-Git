-- create the tables for our movies


SELECT * From actors WHERE dob < '1970-1-1';